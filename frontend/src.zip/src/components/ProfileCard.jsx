import { useState } from 'react'
import { Heart, Mail, Eye, ShieldCheck } from 'lucide-react'
import MatchScore from './MatchScore'

/**
 * ProfileCard — Glassmorphic card for each match in the grid
 * Features animated entrance, match score, verification badges, status tags, and action buttons
 */
export default function ProfileCard({ match, index = 0, onViewProfile, onSendEmail, user }) {
  const [liked, setLiked] = useState(false)
  const { profile, score } = match
  const totalScore = score?.overall_score || 0
  const matchReasons = score?.match_reasons || []

  // Determine match category
  const getCategory = () => {
    if (totalScore >= 90) return { label: 'Soulmate Match ✨', className: 'badge-soulmate' }
    if (totalScore >= 75) return { label: 'High Potential 🔥', className: 'badge-high' }
    if (totalScore >= 60) return { label: 'Good Match 👍', className: 'badge-good' }
    return { label: 'Worth Exploring 🌱', className: 'badge-moderate' }
  }

  const category = getCategory()
  const dietEmoji = profile?.diet?.toLowerCase()?.includes('veg') ? '🥗' : '🍖'

  return (
    <div
      className="glass-card"
      style={{
        padding: '20px',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: '12px',
        animation: `fadeInUp 0.5s ease ${index * 0.05}s both`,
        position: 'relative'
      }}
    >
      {/* Match Score Badge — Top Right */}
      <div style={{ position: 'absolute', top: '14px', right: '14px' }}>
        <MatchScore score={totalScore} size={48} />
      </div>

      {/* Status Tag — Top Left */}
      {profile?.status_tag && (
        <div style={{ position: 'absolute', top: '14px', left: '14px' }}>
          <span className={`badge badge-status badge-status-${profile.status_tag?.toLowerCase()}`}
                style={{ fontSize: '0.65rem', padding: '3px 8px' }}>
            {profile.status_tag}
          </span>
        </div>
      )}

      {/* Profile Photo with verification badge */}
      <div style={{ position: 'relative', marginTop: '8px' }}>
        <div className="photo-ring">
          <img
            src={profile?.photo_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(profile?.name || 'user')}`}
            alt={profile?.name}
            style={{ width: '76px', height: '76px' }}
          />
        </div>
        {profile?.photo_verified && (
          <div style={{
            position: 'absolute', bottom: '0', right: '-2px',
            background: '#22c55e', borderRadius: '50%', padding: '3px',
            display: 'flex', border: '2px solid var(--bg-primary)'
          }}>
            <ShieldCheck size={10} color="white" />
          </div>
        )}
      </div>

      {/* Category Badge */}
      <span className={`badge ${category.className}`} style={{ fontSize: '0.72rem' }}>{category.label}</span>

      {/* Name, Age, City */}
      <div style={{ textAlign: 'center' }}>
        <h3 className="font-heading" style={{ fontSize: '1.05rem', fontWeight: 700, marginBottom: '2px' }}>
          {profile?.name || 'Unknown'}
        </h3>
        <p style={{ fontSize: '0.82rem', color: 'var(--text-secondary)' }}>
          {profile?.age || '—'} • {profile?.city || '—'}
        </p>
      </div>

      {/* Profession + Company */}
      <p style={{
        fontSize: '0.78rem', color: 'var(--lavender)', textAlign: 'center',
        overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', width: '100%',
        fontWeight: 500
      }}>
        {profile?.profession || ''}
        {profile?.company && profile.company !== 'Self-Employed' && profile.company !== 'Freelancer'
          ? ` • ${profile.company}` : ''}
      </p>

      {/* Top Match Reason (key differentiator) */}
      {matchReasons.length > 0 && (
        <p style={{
          fontSize: '0.73rem', color: '#22c55e', textAlign: 'center',
          lineHeight: 1.4, padding: '4px 8px', background: 'rgba(34, 197, 94, 0.05)',
          borderRadius: 'var(--radius-sm)', border: '1px solid rgba(34, 197, 94, 0.1)',
          width: '100%'
        }}>
          ✓ {matchReasons[0]}
        </p>
      )}

      {/* Quick Info Pills */}
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '5px', justifyContent: 'center' }}>
        {profile?.diet && (
          <span className="info-pill" style={{ fontSize: '0.7rem', padding: '3px 8px' }}>{dietEmoji} {profile.diet}</span>
        )}
        {profile?.religion && (
          <span className="info-pill" style={{ fontSize: '0.7rem', padding: '3px 8px' }}>🙏 {profile.religion}</span>
        )}
        {profile?.mother_tongue && (
          <span className="info-pill" style={{ fontSize: '0.7rem', padding: '3px 8px' }}>🗣️ {profile.mother_tongue}</span>
        )}
        {profile?.education && (
          <span className="info-pill" style={{ fontSize: '0.7rem', padding: '3px 8px' }}>🎓 {profile.education}</span>
        )}
      </div>

      {/* Verification row */}
      <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap', justifyContent: 'center' }}>
        {profile?.photo_verified && (
          <span className="verification-badge verification-badge-verified" style={{ fontSize: '0.65rem', padding: '2px 8px' }}>
            <ShieldCheck size={10} /> Photo ✓
          </span>
        )}
        {profile?.income_verified && (
          <span className="verification-badge verification-badge-verified" style={{ fontSize: '0.65rem', padding: '2px 8px' }}>
            💰 Income ✓
          </span>
        )}
      </div>

      {/* Action Buttons */}
      <div style={{ display: 'flex', gap: '8px', marginTop: '4px' }}>
        <button
          className="btn-icon"
          onClick={() => setLiked(!liked)}
          title="Like"
          style={{
            color: liked ? '#e11d48' : 'var(--text-secondary)',
            borderColor: liked ? 'rgba(225, 29, 72, 0.4)' : 'var(--border-subtle)'
          }}
        >
          <Heart size={16} fill={liked ? '#e11d48' : 'none'} />
        </button>
        <button
          className="btn-icon"
          onClick={() => onSendEmail && onSendEmail(match)}
          title="Send Email"
        >
          <Mail size={16} />
        </button>
        <button
          className="btn-icon"
          onClick={() => onViewProfile && onViewProfile(profile?.id || profile?.name)}
          title="View Profile"
          style={{ color: 'var(--lavender)', borderColor: 'rgba(167, 139, 250, 0.3)' }}
        >
          <Eye size={16} />
        </button>
      </div>
    </div>
  )
}
