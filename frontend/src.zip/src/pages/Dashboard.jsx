import { useState, useEffect, useMemo, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import axios from 'axios'
import { Users, Frown, Loader2, Clock, Eye, Mail, Sparkles, LogIn } from 'lucide-react'
import Navbar from '../components/Navbar'
import FilterPanel from '../components/FilterPanel'
import ProfileCard from '../components/ProfileCard'
import EmailModal from '../components/EmailModal'
import { useToast } from '../components/Toast'

/**
 * Dashboard — Main matches page
 * Features filter sidebar, recent activity, responsive match grid, and email modal
 */
const DEFAULT_FILTERS = {
  ageMin: 21,
  ageMax: 40,
  religion: '',
  diet: '',
  city: '',
  openToRelocate: '',
  openToPets: '',
  wantsChildren: '',
  statusTag: '',
  stage: '',
}

export default function Dashboard({ user, token, onLogout }) {
  const [matches, setMatches] = useState([])
  const [loading, setLoading] = useState(true)
  const [filters, setFilters] = useState({ ...DEFAULT_FILTERS })
  const [sortBy, setSortBy] = useState('score')
  const [emailModal, setEmailModal] = useState({ open: false, match: null })
  const [activities, setActivities] = useState([])
  const [showActivity, setShowActivity] = useState(true)
  const navigate = useNavigate()
  const { addToast } = useToast()

  const fetchMatches = useCallback(async () => {
    setLoading(true)
    try {
      const params = { user_id: user?.id || user?.user_id }
      // Add non-empty filter values
      Object.entries(filters).forEach(([key, value]) => {
        if (value !== '' && value !== undefined) {
          // Map camelCase to snake_case for backend
          const paramKey = key === 'statusTag' ? 'status_tag' : key
          params[paramKey] = value
        }
      })

      const res = await axios.get('/api/matches', { params })
      setMatches(res.data.matches || [])
    } catch (err) {
      addToast('Failed to load matches. Please try again.', 'error')
      setMatches([])
    } finally {
      setLoading(false)
    }
  }, [filters, user?.id, user?.user_id]) // eslint-disable-line react-hooks/exhaustive-deps

  // Fetch recent activity
  const fetchActivity = useCallback(async () => {
    try {
      const res = await axios.get('/api/activity')
      setActivities(res.data.activities || [])
    } catch {
      // silently fail — activity is non-critical
    }
  }, [])

  // Fetch on mount
  useEffect(() => {
    fetchMatches()
    fetchActivity()
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  // Sort matches
  const sortedMatches = useMemo(() => {
    const sorted = [...matches]
    switch (sortBy) {
      case 'score':
        return sorted.sort((a, b) => (b.score?.overall_score || 0) - (a.score?.overall_score || 0))
      case 'age':
        return sorted.sort((a, b) => (a.profile?.age || 0) - (b.profile?.age || 0))
      case 'name':
        return sorted.sort((a, b) => (a.profile?.name || '').localeCompare(b.profile?.name || ''))
      default:
        return sorted
    }
  }, [matches, sortBy])

  const handleReset = () => {
    setFilters({ ...DEFAULT_FILTERS })
    setTimeout(() => fetchMatches(), 0)
  }

  // Activity icon mapper
  const getActivityIcon = (action) => {
    switch (action) {
      case 'login': return <LogIn size={14} />
      case 'viewed_profile': return <Eye size={14} />
      case 'sent_intro': return <Mail size={14} />
      case 'ai_insight': return <Sparkles size={14} />
      default: return <Clock size={14} />
    }
  }

  const getActivityColor = (action) => {
    switch (action) {
      case 'login': return 'var(--lavender)'
      case 'viewed_profile': return 'var(--coral)'
      case 'sent_intro': return '#22c55e'
      case 'ai_insight': return 'var(--gold)'
      default: return 'var(--text-muted)'
    }
  }

  const formatTime = (timestamp) => {
    if (!timestamp) return ''
    try {
      const d = new Date(timestamp)
      const now = new Date()
      const diffMs = now - d
      const diffMin = Math.floor(diffMs / 60000)
      if (diffMin < 1) return 'Just now'
      if (diffMin < 60) return `${diffMin}m ago`
      const diffHr = Math.floor(diffMin / 60)
      if (diffHr < 24) return `${diffHr}h ago`
      return d.toLocaleDateString()
    } catch {
      return ''
    }
  }

  return (
    <div className="page-enter" style={{ minHeight: '100vh', background: 'var(--bg-primary)' }}>
      <Navbar user={user} onLogout={onLogout} />

      <main style={{
        paddingTop: '80px', paddingLeft: '24px', paddingRight: '24px', paddingBottom: '40px',
        maxWidth: '1400px', margin: '0 auto', display: 'flex', gap: '24px'
      }}>
        {/* Filter Sidebar */}
        <FilterPanel
          filters={filters}
          setFilters={setFilters}
          onApply={fetchMatches}
          onReset={handleReset}
        />

        {/* Main Content */}
        <div style={{ flex: 1, minWidth: 0 }}>
          {/* Recent Activity Section */}
          {activities.length > 0 && showActivity && (
            <div className="glass-card-static animate-fadeInUp" style={{ padding: '18px', marginBottom: '20px' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '12px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <Clock size={16} color="var(--lavender)" />
                  <h3 className="font-heading" style={{ fontSize: '0.95rem', fontWeight: 700 }}>Recent Activity</h3>
                </div>
                <button
                  onClick={() => setShowActivity(false)}
                  style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer', fontSize: '0.75rem' }}
                >
                  Hide
                </button>
              </div>
              <div style={{ display: 'flex', gap: '10px', overflowX: 'auto', paddingBottom: '4px' }}>
                {activities.slice(0, 8).map((act, i) => (
                  <div key={i} style={{
                    display: 'flex', alignItems: 'center', gap: '8px', padding: '8px 12px',
                    background: 'rgba(167, 139, 250, 0.04)', borderRadius: 'var(--radius-sm)',
                    border: '1px solid rgba(167, 139, 250, 0.08)', whiteSpace: 'nowrap', flexShrink: 0,
                    fontSize: '0.78rem'
                  }}>
                    <span style={{ color: getActivityColor(act.action) }}>{getActivityIcon(act.action)}</span>
                    <span style={{ color: 'var(--text-secondary)' }}>{act.details}</span>
                    <span style={{ color: 'var(--text-muted)', fontSize: '0.7rem' }}>{formatTime(act.timestamp)}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Grid Header */}
          <div style={{
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            marginBottom: '24px', flexWrap: 'wrap', gap: '12px'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <Users size={20} color="var(--rose-secondary)" />
              <h2 className="font-heading" style={{ fontSize: '1.3rem', fontWeight: 700 }}>
                {loading ? 'Finding Matches...' : `${sortedMatches.length} Matches Found`}
              </h2>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Sort by:</label>
              <select
                className="input-glass"
                value={sortBy}
                onChange={e => setSortBy(e.target.value)}
                style={{ width: 'auto', padding: '8px 36px 8px 12px', fontSize: '0.85rem' }}
              >
                <option value="score">Score</option>
                <option value="age">Age</option>
                <option value="name">Name</option>
              </select>
            </div>
          </div>

          {/* Loading Skeletons */}
          {loading && (
            <div className="match-grid">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="skeleton glass-card-static"
                  style={{ height: '380px', animation: `fadeInUp 0.3s ease ${i * 0.1}s both` }} />
              ))}
            </div>
          )}

          {/* Empty State */}
          {!loading && sortedMatches.length === 0 && (
            <div className="animate-fadeInUp" style={{ textAlign: 'center', padding: '80px 20px' }}>
              <Frown size={64} color="var(--text-muted)" style={{ marginBottom: '16px', opacity: 0.5 }} />
              <h3 className="font-heading" style={{ fontSize: '1.3rem', fontWeight: 600, marginBottom: '8px' }}>
                No matches found
              </h3>
              <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem' }}>
                Try adjusting your filters to discover more profiles
              </p>
            </div>
          )}

          {/* Match Grid */}
          {!loading && sortedMatches.length > 0 && (
            <div className="match-grid">
              {sortedMatches.map((match, index) => (
                <ProfileCard
                  key={match.profile?.id || match.profile?.name || index}
                  match={match}
                  index={index}
                  onViewProfile={(id) => navigate(`/profile/${id}`)}
                  onSendEmail={(m) => setEmailModal({ open: true, match: m })}
                  user={user}
                />
              ))}
            </div>
          )}
        </div>
      </main>

      {/* Email Modal */}
      {emailModal.open && emailModal.match && (
        <EmailModal
          match={emailModal.match}
          user={user}
          onClose={() => setEmailModal({ open: false, match: null })}
        />
      )}
    </div>
  )
}
